<?php

/**
 * Displays info about the RaspAP project
 */
function DisplayAbout()
{
    echo renderTemplate("about");
}
